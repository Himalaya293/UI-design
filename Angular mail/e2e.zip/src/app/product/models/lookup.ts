export class Lookup {
    name:string;
    code:string;
    category:string;
}
